require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(helmet());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

const allowed = (process.env.CORS_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
app.use(cors({ origin: allowed.length ? allowed : true }));

const limiter = rateLimit({ windowMs: 60 * 1000, max: 120 });
app.use("/api", limiter);

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB error:", err.message));

const userSchema = new mongoose.Schema({
  email: { type: String, unique: true, lowercase: true, trim: true },
  passwordHash: String,
  name: String,
  role: { type: String, enum: ["user","admin"], default: "user" },
  balance: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});

const categorySchema = new mongoose.Schema({
  name: String, slug: { type: String, unique: true }, icon: String,
  active: { type: Boolean, default: true }, sort: { type: Number, default: 0 }
});

const productSchema = new mongoose.Schema({
  title: String, slug: { type: String, unique: true }, game: String,
  categoryId: mongoose.Schema.Types.ObjectId,
  description: String, image: String,
  price: Number, salePrice: Number,
  type: { type: String, enum: ["account","item","service"], default: "account" },
  active: { type: Boolean, default: true },
  stock: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});

const inventorySchema = new mongoose.Schema({
  productId: mongoose.Schema.Types.ObjectId,
  secret: String,
  sold: { type: Boolean, default: false },
  orderId: mongoose.Schema.Types.ObjectId,
  createdAt: { type: Date, default: Date.now }
});

const orderSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  items: [{ productId: mongoose.Schema.Types.ObjectId, qty: Number, price: Number }],
  total: Number,
  status: { type: String, enum: ["pending","paid","completed","cancelled"], default: "pending" },
  paymentMethod: String,
  createdAt: { type: Date, default: Date.now }
});

const transactionSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  amount: Number,
  type: { type: String, enum: ["deposit","purchase","refund","adjustment"] },
  status: { type: String, enum: ["pending","success","failed"], default: "pending" },
  note: String, reference: String,
  createdAt: { type: Date, default: Date.now }
});

const settingSchema = new mongoose.Schema({
  key: { type: String, unique: true }, value: mongoose.Schema.Types.Mixed
});

const logSchema = new mongoose.Schema({
  actorId: mongoose.Schema.Types.ObjectId, action: String, meta: Object,
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model("User", userSchema);
const Category = mongoose.model("Category", categorySchema);
const Product = mongoose.model("Product", productSchema);
const Inventory = mongoose.model("Inventory", inventorySchema);
const Order = mongoose.model("Order", orderSchema);
const Transaction = mongoose.model("Transaction", transactionSchema);
const Setting = mongoose.model("Setting", settingSchema);
const Log = mongoose.model("Log", logSchema);

function sign(user) {
  return jwt.sign({ id: user._id.toString(), role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });
}
function auth(req,res,next) {
  try {
    const token = (req.headers.authorization || "").replace("Bearer ","");
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { res.status(401).json({message:"Unauthorized"}); }
}
function admin(req,res,next) {
  if (req.user?.role !== "admin") return res.status(403).json({message:"Admin only"});
  next();
}
async function audit(actorId, action, meta={}) { await Log.create({actorId,action,meta}); }

app.get("/api/health",(req,res)=>res.json({ok:true, time:new Date()}));

app.post("/api/auth/register", async (req,res)=>{
  const {email,password,name} = req.body;
  if (!email || !password || password.length < 6) return res.status(400).json({message:"Email/password không hợp lệ"});
  if (await User.findOne({email})) return res.status(409).json({message:"Email đã tồn tại"});
  const passwordHash = await bcrypt.hash(password,12);
  const user = await User.create({email,passwordHash,name});
  res.json({token:sign(user), user:{id:user._id,email:user.email,name:user.name,role:user.role,balance:user.balance}});
});

app.post("/api/auth/login", async (req,res)=>{
  const user = await User.findOne({email:req.body.email});
  if (!user || !(await bcrypt.compare(req.body.password || "",user.passwordHash))) return res.status(401).json({message:"Sai tài khoản hoặc mật khẩu"});
  res.json({token:sign(user), user:{id:user._id,email:user.email,name:user.name,role:user.role,balance:user.balance}});
});

app.get("/api/me",auth,async(req,res)=>{
  const u=await User.findById(req.user.id).select("-passwordHash");
  res.json(u);
});

app.get("/api/categories",async(req,res)=>res.json(await Category.find({active:true}).sort({sort:1})));
app.get("/api/products",async(req,res)=>{
  const q={active:true};
  if(req.query.game) q.game=req.query.game;
  if(req.query.categoryId) q.categoryId=req.query.categoryId;
  if(req.query.search) q.$or=[{title:new RegExp(req.query.search,"i")},{game:new RegExp(req.query.search,"i")}];
  res.json(await Product.find(q).sort({createdAt:-1}));
});
app.get("/api/products/:id",async(req,res)=>{
  const p=await Product.findOne({_id:req.params.id,active:true});
  if(!p) return res.status(404).json({message:"Không tìm thấy"});
  res.json(p);
});

app.post("/api/orders",auth,async(req,res)=>{
  const {productId,qty=1,paymentMethod="balance"}=req.body;
  const p=await Product.findOne({_id:productId,active:true});
  if(!p || p.stock < qty) return res.status(400).json({message:"Sản phẩm hết hàng"});
  const price=(p.salePrice ?? p.price)*qty;
  const user=await User.findById(req.user.id);
  if(paymentMethod==="balance" && user.balance < price) return res.status(400).json({message:"Số dư không đủ"});
  const order=await Order.create({userId:user._id,items:[{productId:p._id,qty,price:p.salePrice ?? p.price}],total:price,status:paymentMethod==="balance"?"paid":"pending",paymentMethod});
  if(paymentMethod==="balance"){
    user.balance-=price; await user.save();
    const inv=await Inventory.find({productId:p._id,sold:false}).limit(qty);
    for(const item of inv){ item.sold=true; item.orderId=order._id; await item.save(); }
    p.stock-=qty; await p.save();
    await Transaction.create({userId:user._id,amount:-price,type:"purchase",status:"success",reference:order._id.toString()});
    order.status="completed"; await order.save();
  }
  await audit(user._id,"CREATE_ORDER",{orderId:order._id.toString(),total:price});
  res.json(order);
});

app.get("/api/orders",auth,async(req,res)=>res.json(await Order.find({userId:req.user.id}).sort({createdAt:-1})));
app.get("/api/inventory/purchased",auth,async(req,res)=>{
  const rows=await Inventory.find({sold:true}).populate("productId").sort({createdAt:-1});
  const ids=await Order.find({userId:req.user.id}).distinct("_id");
  res.json(rows.filter(x=>ids.some(id=>id.equals(x.orderId))));
});

app.get("/api/settings/public",async(req,res)=>{
  const rows=await Setting.find({key:/^(shop|payment_public|social)_/});
  res.json(Object.fromEntries(rows.map(x=>[x.key,x.value])));
});

/* Admin */
app.get("/api/admin/dashboard",auth,admin,async(req,res)=>{
  const [users,products,orders,paid] = await Promise.all([
    User.countDocuments(),Product.countDocuments(),Order.countDocuments({status:{$in:["paid","completed"]}}),
    Order.aggregate([{$match:{status:{$in:["paid","completed"]}}},{$group:{_id:null,total:{$sum:"$total"}}}])
  ]);
  res.json({users,products,orders,revenue:paid[0]?.total||0});
});

app.get("/api/admin/products",auth,admin,async(req,res)=>res.json(await Product.find().sort({createdAt:-1})));
app.post("/api/admin/products",auth,admin,async(req,res)=>{
  const p=await Product.create(req.body); await audit(req.user.id,"CREATE_PRODUCT",{id:p._id}); res.json(p);
});
app.put("/api/admin/products/:id",auth,admin,async(req,res)=>{
  const p=await Product.findByIdAndUpdate(req.params.id,req.body,{new:true}); res.json(p);
});
app.delete("/api/admin/products/:id",auth,admin,async(req,res)=>{
  await Product.findByIdAndDelete(req.params.id); res.json({ok:true});
});

app.get("/api/admin/categories",auth,admin,async(req,res)=>res.json(await Category.find().sort({sort:1})));
app.post("/api/admin/categories",auth,admin,async(req,res)=>res.json(await Category.create(req.body)));
app.put("/api/admin/categories/:id",auth,admin,async(req,res)=>res.json(await Category.findByIdAndUpdate(req.params.id,req.body,{new:true})));
app.delete("/api/admin/categories/:id",auth,admin,async(req,res)=>{await Category.findByIdAndDelete(req.params.id);res.json({ok:true});});

app.post("/api/admin/inventory/import",auth,admin,async(req,res)=>{
  const {productId,lines=[]}=req.body;
  const docs=lines.filter(Boolean).map(secret=>({productId,secret}));
  const inserted=await Inventory.insertMany(docs);
  await Product.findByIdAndUpdate(productId,{$inc:{stock:inserted.length}});
  await audit(req.user.id,"IMPORT_INVENTORY",{productId,count:inserted.length});
  res.json({count:inserted.length});
});

app.get("/api/admin/orders",auth,admin,async(req,res)=>res.json(await Order.find().sort({createdAt:-1}).limit(200)));
app.get("/api/admin/users",auth,admin,async(req,res)=>res.json(await User.find().select("-passwordHash").sort({createdAt:-1}).limit(200)));

app.post("/api/admin/users/:id/balance",auth,admin,async(req,res)=>{
  const amount=Number(req.body.amount);
  if(!Number.isFinite(amount)) return res.status(400).json({message:"Amount invalid"});
  const u=await User.findByIdAndUpdate(req.params.id,{$inc:{balance:amount}},{new:true}).select("-passwordHash");
  await Transaction.create({userId:u._id,amount,type:"adjustment",status:"success",note:"Admin adjustment",reference:req.user.id});
  await audit(req.user.id,"ADJUST_BALANCE",{userId:u._id.toString(),amount});
  res.json(u);
});

app.get("/api/admin/settings",auth,admin,async(req,res)=>res.json(await Setting.find()));
app.put("/api/admin/settings",auth,admin,async(req,res)=>{
  const {key,value}=req.body;
  const s=await Setting.findOneAndUpdate({key},{key,value},{upsert:true,new:true});
  await audit(req.user.id,"UPDATE_SETTING",{key});
  res.json(s);
});

/* Manual bank transfer deposit request. Actual automatic confirmation must be wired
   to a legitimate bank/payment provider webhook and verified server-side. */
app.post("/api/deposits",auth,async(req,res)=>{
  const amount=Number(req.body.amount);
  if(!Number.isFinite(amount)||amount<=0) return res.status(400).json({message:"Số tiền không hợp lệ"});
  const reference=(process.env.PAYMENT_PREFIX||"GSP")+"_"+Date.now()+"_"+req.user.id.toString().slice(-6);
  const tx=await Transaction.create({userId:req.user.id,amount,type:"deposit",status:"pending",reference});
  res.json({transactionId:tx._id,reference,bankName:process.env.BANK_NAME,bankAccount:process.env.BANK_ACCOUNT,bankOwner:process.env.BANK_OWNER});
});

app.post("/api/payments/webhook",async(req,res)=>{
  const secret=req.headers["x-webhook-secret"];
  if(!process.env.PAYMENT_WEBHOOK_SECRET || secret!==process.env.PAYMENT_WEBHOOK_SECRET) return res.status(401).json({message:"Invalid webhook"});
  // Provider-specific verification and mapping must be implemented here.
  res.json({received:true});
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`API running on ${port}`));
