require("dotenv").config();
const mongoose=require("mongoose"),bcrypt=require("bcryptjs");
const User=require("./server"); // server starts API; models are intentionally created in server.js
(async()=>{
  // This script is kept as a simple bootstrap helper.
  console.log("Seed helper: run server.js first to create the database connection.");
  process.exit(0);
})();
