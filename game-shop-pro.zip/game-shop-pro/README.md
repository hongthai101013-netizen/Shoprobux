# GAME SHOP PRO

Website bán tài khoản/game items theo phong cách shop game Việt hiện đại.

> Lưu ý: giao diện được lấy cảm hứng từ bố cục cửa hàng game phổ biến và trang tham khảo, không sao chép logo/ảnh/nội dung thương hiệu. Backend phải chạy trên hosting Node.js; GitHub Pages chỉ host frontend tĩnh.

## Kiến trúc
- Frontend: HTML/CSS/JS thuần, deploy GitHub Pages.
- Backend: Node.js + Express + MongoDB.
- Auth: JWT + bcrypt.
- Admin: quản lý danh mục, sản phẩm/acc, tồn kho, đơn hàng, người dùng, banner, cấu hình shop.
- Thanh toán: thiết kế sẵn module VietQR/chuyển khoản + webhook; cần điền thông tin ngân hàng/cổng thanh toán thật trong `.env`.
- Không lưu mật khẩu admin dạng plain text.

## Chạy local

### Backend
```bash
cd backend
npm install
cp .env.example .env
npm run seed
npm run dev
```

Backend mặc định: http://localhost:3000

Tài khoản admin demo sau khi seed:
- Email: admin@example.com
- Password: ChangeMe123!

Hãy đổi mật khẩu ngay khi đăng nhập.

### Frontend
Mở `frontend/index.html` bằng Live Server hoặc deploy thư mục frontend lên GitHub Pages.

Trong `frontend/config.js`, đặt:
```js
window.API_BASE = "http://localhost:3000/api";
```

## Deploy
1. Push toàn bộ repo lên GitHub.
2. GitHub Pages: deploy thư mục frontend.
3. Backend: Render/Railway/Fly.io hoặc VPS Node.js.
4. MongoDB: MongoDB Atlas.
5. Đặt `CORS_ORIGINS` là domain GitHub Pages.
6. Điền cấu hình thanh toán thật trong biến môi trường.
7. Không commit `.env`.

## Chức năng
### Khách
- Trang chủ/banner
- Danh mục game
- Tìm kiếm/lọc/sắp xếp
- Chi tiết sản phẩm
- Giỏ hàng
- Đăng ký/đăng nhập
- Nạp tiền
- Mua hàng
- Lịch sử đơn
- Kho sản phẩm đã mua
- Hồ sơ
- Hỗ trợ

### Admin
- Dashboard doanh thu/đơn/tồn kho
- CRUD danh mục
- CRUD sản phẩm
- Nhập kho tài khoản theo dòng `username|password|extra`
- Quản lý đơn hàng
- Quản lý người dùng
- Banner
- Cấu hình shop
- Nhật ký hoạt động

## Quan trọng
Đây là bộ khung full-stack có thể chạy và mở rộng. Muốn nhận tiền tự động thực tế phải kết nối tài khoản ngân hàng/cổng thanh toán hợp lệ và webhook xác thực chữ ký; không nên giả lập giao dịch thành công ở frontend.
